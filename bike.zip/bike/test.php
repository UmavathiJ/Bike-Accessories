
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="./style.css">
    <link rel="stylesheet" href="./bootstrap.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.1.1/css/fontawesome.min.css" integrity="sha384-zIaWifL2YFF1qaDiAo0JFgsmasocJ/rqu7LKYH8CoBEXqGbb9eO+Xi3s6fQhgFWM" crossorigin="anonymous">
    <link rel="stylesheet" href="./fontawesome.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css">
   
<meta charset="utf-8">
<title>MOtorCycle
    3
</title>
</head>
<body>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <div class="fixed-header">
   <a ><img src="./logo.png" style="width:50px"></a>
            <ul style="display:flex;float: right;">
            <li id="home">HOME</li></br>
            <li class="mg10" id="motor">BIKE ACCESSORIES</li></br>
            <li class="mg10" id="services">SERVICES</li> </br>
             <li class="mg10"  id="contact">CONTACT US</li></br>
             <li class="mg10" id="logout" data-toggle="modal" data-target="#exampleModal"> LOG OUT</li></br>
            </ul>
      
    </div>
    <section>
    <div class="card" style="height: auto;overflow: hidden;">
     <h4 style="text-align: left;font-style: italic;">Contact Us</h4>
     <div class="row">
        <div class="col-lg-2 col-md-2"></div>
        <div class="col-lg-8 col-md-8">
            <div class="card">
                <div class="row"></div>
                <div class="col-lg-6 col-md-6">
                    <span><i class="bi bi-telephone-fill"></i><h6 class="call">Call us :9087654321</h6></span>
                </div>
                <div class="col-lg-6 col-md-6">
                    <span><h6 class="email">Email us :ramesh@gmail.com</h6></span>
                </div>
              
           

            <br>
            <div class="row">
                <div class="col-lg-12 col-md-12">
              <!-- <form>
                    <div class="form-group">
                     <form action="test.php"method="post">   
                    <label for="exampleInputEmail1">Name</label>
                        <input type="text" id="name"class="form-control"  placeholder="Enter Name">
                      </div>
                    <div class="form-group">
                      <label for="exampleInputEmail1">Email address</label>
                      <input type="email" id="email"class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email">
                      <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
                    </div>
                    <div class="form-group">
                        <label > Mobile Number</label>
                        <input type="number"id="mobilenumber" class="form-control"  placeholder="Enter Phone Number">
                      </div>
                    <div class="form-group form-check">
                      <input type="checkbox" class="form-check-input" id="exampleCheck1">
                      <label class="form-check-label" for="exampleCheck1">I agree to Terms & Condition</label>
                    </div>
                    <button type="submit" id="submit"class="btn btn-primary">Submit</button>
                  </form>
                </div>
            </div> -->
           
      <div class="modal-content">
        <div class="modal-header">
          
          <h4 class="modal-title">Let Us Contact You </h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        <div class="modal-body">
 
          <form action="test.php" method="post">
            Name: <input type="text" class="form-control" name="name"><br>
            Email: <input type="text" class="form-control" name="email"><br>
            Mobile Number: <input type="number"  class="form-control" name="mobilenumber"><br>
            <input type="submit" name="submit">
            </form> 
        <div class="modal-footer">
        </div>
      </div>
  
    </div>
  
  </div>
           
            </div>
        </div>
        <div class="col-lg-2 col-md-2"></div>
     </div>
 
    </div>
    
    </section>
    
   
    
    <div class="fixed-footer">
        <div class="container">Copyright &copy; 2022 RONALDO BIKE SERVICES</div>        
    </div>
    </body>
</html>
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">LOG OFF</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
         Are you sure you want to logout?
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <button type="button" class="btn btn-primary" id="logout1">Log Out</button>
        </div>
      </div>
    </div>
  </div>
<script>
$(document).ready(function() {
    $("#motor").click(function(){
      location.href = 'connect.php';
    }); 
    $("#home").click(function(){
      location.href = 'index.php';
    }); 
    $("#services").click(function(){
      location.href = 'services.html';
    });
    $("#logout1").click(function(){
      location.href = 'login1.php';
    });
    $("#contact").click(function(){
      location.href = 'test.php';
    });
    
});
  </script>
 <style>

.servicecard:hover {
    transform: scale(1.1);
  }
</style>

	
  <center>
		<?php
     function gyalert($msg) {
        echo "<script type='text/javascript'>alert('$msg');</script>";
    }
	
		$conn = mysqli_connect("localhost", "root", "", "race");
		if($conn === false){
			die("ERROR: Could not connect. "
				. mysqli_connect_error());
		}
		
		$name = $_REQUEST['name'];
		$email = $_REQUEST['email'];
		$mobilenumber = $_REQUEST['mobilenumber'];
	
        if(isset($_POST['submit'])){
		$sql = "INSERT INTO run VALUES ('$name',
			'$email','$mobilenumber')";
		
		if(mysqli_query($conn, $sql)){
            gyalert("Contact Record Inserted");

		} else{
			echo "ERROR: Hush! Sorry $sql. "
				. mysqli_error($conn);
		}
		mysqli_close($conn);
    }
		?>
	</center>


</body>

</html>




















