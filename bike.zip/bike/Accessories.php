
<?php
 
 $conn = mysqli_connect("localhost", "root", "", "base");
 
// Checking for connections
if ($conn->connect_error) {
    die('Connect Error (' .
    $conn->connect_errno . ') '.
    $conn->connect_error);
}
 

$sql = " SELECT * FROM data";
$result = $conn->query($sql);
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
 
<head>
<head>
<link rel="stylesheet" href="./style.css">
    <link rel="stylesheet" href="./bootstrap.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.1.1/css/fontawesome.min.css" integrity="sha384-zIaWifL2YFF1qaDiAo0JFgsmasocJ/rqu7LKYH8CoBEXqGbb9eO+Xi3s6fQhgFWM" crossorigin="anonymous">
    <title>MOtorCycle
    3
</title>
</head>

    <meta charset="UTF-8">
    <title>List of Accessories</title>
    <style>
        table {
            font-size: normal;
            border: 1px solid black;
            background-color: white;
            width:70%;
        }
 
        h1 {
            text-align: center;
            color: #006600;
            font-size: xx-large;
            font-family: 'Gill Sans', 'Gill Sans MT',
            ' Calibri', 'Trebuchet MS', 'sans-serif';
        }
 
        td {
            background-color: #E4F5D4;
            border: 1px solid black;
        }
 
        th,
        td {
            font-weight: bold;
            border: 1px solid black;
            padding: 10px;
            text-align: center;
        }
 
        td {
            font-weight: lighter;
        }

    </style>
</head>
 
<body>
    
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <div class="fixed-header">
   <a ><img src="./logo.png" style="width:50px"></a>
            <ul style="display:flex;float: right;">
            <li id="home">HOME</li></br>
            <li class="mg10"  id="motor">BIKE ACCESSORIES</li></br>
           <li class="mg10" id="services">SERVICES</li> </br>
            <li class="mg10" id="contact">CONTACT US</li></br>
            <li class="mg10" id="logout" data-toggle="modal" data-target="#exampleModal"> LOG OUT</li></br>
            </ul>
      
    </div>
    <div class="ScrollStyle">
    <section>
    <div class="card" style="background: #9e9e9e6b;
            height: auto;overflow-y: hidden;">
            <h5 class="bike7">List of booked users</h5>
            <div class="row">
            <div class="col-lg-2 col-md-2"></div>
                <div class="col-lg-8 col-md-8">
               <table style="margin-top:14px">
            <tr>
                <th>Accessories Name</th>
                <th>Address</th>
                <th>Mobile Number</th>
              
            </tr>
            <?php
                while($rows=$result->fetch_assoc())
                {
            ?>
            <tr>
                <td><?php echo $rows['name'];?></td>
                <td><?php echo $rows['address'];?></td>
                <td><?php echo $rows['mobilenumber'];?></td>
            </tr>
            <?php
                }
            ?>
        </table>
                </div>
                <div class="col-lg-2 col-md-2"></div>

               
            </div>
            
     
        </div>
     
    </section>
            </div>
            <div class="fixed-footer">
        <div class="container">Copyright &copy; 2022 RONALDO BIKE ACCESSORIES</div>     
    </div>
</body>
 
</html>



<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">LOG OFF</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
         Are you sure you want to logout?
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <button type="button" class="btn btn-primary" id="logout1">Log Out</button>
        </div>
      </div>
    </div>
  </div>
<script>
$(document).ready(function() {
    $("#motor").click(function(){
      location.href = 'connect.php';
    }); 
    $("#home").click(function(){
      location.href = 'index.php';
    }); 
    $("#services").click(function(){
      location.href = 'services.html';
    });
    $("#logout1").click(function(){
      location.href = 'login1.php';
    });
    $("#contact").click(function(){
      location.href = 'test.php';
    });
});
  </script>