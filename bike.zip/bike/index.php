<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="./style.css">
    <link rel="stylesheet" href="./bootstrap.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.1.1/css/fontawesome.min.css" integrity="sha384-zIaWifL2YFF1qaDiAo0JFgsmasocJ/rqu7LKYH8CoBEXqGbb9eO+Xi3s6fQhgFWM" crossorigin="anonymous">
    <link rel="stylesheet" href="./fontawesome.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.1.1/css/fontawesome.min.css" integrity="sha384-zIaWifL2YFF1qaDiAo0JFgsmasocJ/rqu7LKYH8CoBEXqGbb9eO+Xi3s6fQhgFWM" crossorigin="anonymous">
   
<meta charset="utf-8">
<title>MOtorCycle
    3
</title>
</head>
<body>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <div class="fixed-header">
   <a ><img src="./logo.png" style="width:50px"></a>
            <ul style="display:flex;float: right;">
            <li id="home">HOME</li></br>
            <li class="mg10" id="motor">BIKE ACCESSORIES</li></br>
            <li class="mg10" id="services">SERVICES</li> </br>
            <li class="mg10" id="contact">CONTACT US</li></br>
             <li class="mg10" id="logout" data-toggle="modal" data-target="#exampleModal"> LOG OUT</li></br>
            </ul>
      
    </div>
    <section>
    
    <img src="./bike.jpg" style="width:100%;height:auto;">
    <p class="marquee">
  <span style="font-weight:700;color:#009688;"> RONALD BIKE SERVICE : You deserve the best service and that’s what we deliver Please Contact :ramesh@gmail.com ,9087654321, Place :43,Second Cross Street , Sivakasi &nbsp;</span>
</p>

    <div class="bike-block">
    <h1 class="headercss"> Since 2022</h1>
      <h5  class="header1css"><i>India's best bike portal</i></h5>
  </div>
 
    <div class="text-block">
    <h4>RONALD</h4>
    <p>Bike Accessories</p>
  </div>


    </section>
    <div class="fixed-footer">
    <div class="container">Copyright &copy; 2022 RONALDO BIKE ACCESSORIES</div>       
    </div>
</body>
</html>
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">LOG OFF</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
       Are you sure you want to logout?
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary" id="logout1">Log Out</button>
      </div>
    </div>
  </div>
</div>
  
    </div>
  </div>
<script>
$(document).ready(function() {
  $("#motor").click(function(){
      location.href = 'connect.php';
    }); 
    $("#home").click(function(){
      location.href = 'index.php';
    }); 
    $("#services").click(function(){
      location.href = 'services.html';
    });
   $("#logout1").click(function(){
      location.href = 'login1.php';
    });
    $("#contact").click(function(){
      location.href = 'test.php';
    });
});
  </script>

