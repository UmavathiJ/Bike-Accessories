
<!DOCTYPE html>
<html>

<head>
<link rel="stylesheet" href="./style.css">
    <link rel="stylesheet" href="./bootstrap.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.1.1/css/fontawesome.min.css" integrity="sha384-zIaWifL2YFF1qaDiAo0JFgsmasocJ/rqu7LKYH8CoBEXqGbb9eO+Xi3s6fQhgFWM" crossorigin="anonymous">
    <title>MOtorCycle
    3
</title>
</head>

<body>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <div class="fixed-header">
   <a ><img src="./logo.png" style="width:50px"></a>
            <ul style="display:flex;float: right;">
            <li id="home">HOME</li></br>
            <li class="mg10"  id="motor">BIKE ACCESSORIES</li></br>
           <li class="mg10" id="services">SERVICES</li> </br>
            <li class="mg10" id="contact">CONTACT US</li></br>
            <li class="mg10" id="logout" data-toggle="modal" data-target="#exampleModal"> LOG OUT</li></br>
            </ul>
      
    </div>
    <div class="ScrollStyle">
        <section>
            <div class="card" style="background: #9e9e9e6b;
            height: auto;overflow-y: hidden;">
            <h5 class="bike7">List of all bikes accessories available for sale in India</h5>
            <h6 class="booked" id="bookeditem">Booked Items</h6>
           <div class="row">
            <div class ="col-lg-3 col-md-3">
                <div class="card" style="width: 18rem;width: 18rem;
                top: 19px;
                left: 33px;">
                    <img class="card-img-top" src="./acc3.jpg"  style= "height: 196px;
                    width: 285px"alt="Card image cap">
                    <div class="card-body">
                      <h5 class="card-title">
                        ViaTerra KTM 390 Adv sidestand shoe</h5>
                        <span style="font-weight: 900;"> Price:1,499.00</span>
                      <p class="card-text">
                       </p>
                        <a  class="cardbtn" data-toggle="modal" data-target="#myModal">Buy Now</a>
                    </div>
                  </div>  
            </div>
            <div class ="col-lg-3 col-md-3">
                <div class="card" style="width: 18rem;width: 18rem;
                top: 19px;
                left: 33px;">
                    <img class="card-img-top" src="./acc4.jpg" style= "height: 171px;
                    width: 285px"alt="Card image cap">
                    <div class="card-body">
                      <h5 class="card-title">
                        ViaTerra XPulse sidestand shoe</h5>
                        <span style="font-weight: 900;"> Price:1499</span>
                      <p class="card-text">
                        .</p>
                        <a  class="cardbtn" data-toggle="modal" data-target="#myModal">Buy Now</a>
                    </div>
                  </div>  
            </div>
            <div class ="col-lg-3 col-md-3">
                <div class="card" style="width: 18rem;width: 18rem;
                top: 19px;
                left: 33px;">
                    <img class="card-img-top" src="./acc5.jpg"  style= "height: 214px;
                    width: 286px;"alt="Card image cap">
                    <div class="card-body">
                      <h5 class="card-title">
                        Pro-Spec Easy Clutch Plus</h5>
                        <span style="font-weight: 900;"> Price:2500</span>
                      <p class="card-text">
                       </p>
                        <a  class="cardbtn" data-toggle="modal" data-target="#myModal">Buy Now</a>
                    </div>
                  </div>  
            </div>
            <div class ="col-lg-3 col-md-3">
                <div class="card" style="width: 18rem;width: 18rem;
                top: 19px;
                left: 33px;">
                    <img class="card-img-top" src="./acc6.webp"  style= "height: 200px;
                    width: 287px;"alt="Card image cap">
                    <div class="card-body">
                      <h5 class="card-title">
                        Pro-spec Easy Tags Base Mount</h5>
                        <span style="font-weight: 900;"> Price:750</span>
                      <p class="card-text">
              </p>
              <a  class="cardbtn" data-toggle="modal" data-target="#myModal">Buy Now</a>
                    </div>
                  </div>  
            </div>
           </div>

           <div class="row">
            <div class ="col-lg-3 col-md-3">
                <div class="card" style="width: 18rem;width: 18rem;
                top: 19px;
                left: 33px;">
                    <img class="card-img-top" src="./acc7.webp" style="height: 196px;width: 285px"alt="Card image cap">
                    <div class="card-body">
                      <h5 class="card-title">
                        Pro-spec Easy Tags Base Mount</h5>
                        <span style="font-weight: 900;"> Price:Rs. 650</span>
                      <p class="card-text">
                       </p>
                        <a  class="cardbtn" data-toggle="modal" data-target="#myModal">Buy Now</a>
                    </div>
                  </div>
            </div>
            <div class ="col-lg-3 col-md-3">
                <div class="card" style="width: 18rem;width: 18rem;
                top: 19px;
                left: 33px;">
                    <img class="card-img-top" src="./access8.jpg"  style= "height: 190px;width:190px"alt="Card image cap">
                    <div class="card-body">
                      <h5 class="card-title">
                        Pro-Spec Easy Clutch System -B03 (Long)</h5>
                        <span style="font-weight: 900;"> Price:Rs. 3200</span>
                      <p class="card-text">
                        </p>
                        <a  class="cardbtn" data-toggle="modal" data-target="#myModal">Buy Now</a>
                    </div>
                  </div>  
            </div>
            <div class ="col-lg-3 col-md-3">
                <div class="card" style="width: 18rem;width: 18rem;
                top: 19px;
                left: 33px;">
                    <img class="card-img-top" src="access9.jpg"  style= "height: 180px;
                    width: 287px;"alt="Card image cap">
                    <div class="card-body">
                      <h5 class="card-title">
                        Radiator Guard RE Interceptor & Continental GT 650</h5>
                        <span style="font-weight: 900;"> Price:Rs. 2985</span>
                      <p class="card-text">
                        <a  class="cardbtn" data-toggle="modal" data-target="#myModal">Buy Now</a>
                    </div>
                  </div>  
            </div>
            <div class ="col-lg-3 col-md-3">
                <div class="card" style="width: 18rem;width: 18rem;
                top: 24px;
                left: 33px;">
                    <img class="card-img-top" src="access10.jpg"  style= "height: 180px;
                    width: 287px;"alt="Card image cap">
                    <div class="card-body">
                      <h5 class="card-title">
                        Pro-spec Easy Tags Aux Light mount</h5>
                        <span style="font-weight: 900;"> Price:Rs. 350</span>
                      <p class="card-text">

                      </p>
              <a  class="cardbtn" data-toggle="modal" data-target="#myModal">Buy Now</a>
                    </div>
                  </div>  
            </div>
           </div>
           <div class="row">
            <div class ="col-lg-3 col-md-3">
                <div class="card" style="width: 18rem;width: 18rem;
                top:25px;
                left: 33px;">
                    <img class="card-img-top" src="access1.jpg" style="height:227px; width:289px;"alt="card image cap">
                    <div class="card-body">
                      <h5 class="card-title">
                        ViaTerra Himalayan sidestand shoe</h5>
                        <span style="font-weight: 900;"> Price:Rs.1,499</span>
                      <p class="card-text">
                        </p>
                        <a  class="cardbtn" data-toggle="modal" data-target="#myMod">Buy Now</a>
                    
                    </div>
                  </div>
            </div>
            <div class ="col-lg-3 col-md-3">
                <div class="card" style="width: 18rem;width: 18rem;
                top: 19px;
                left: 33px;">
                    <img class="card-img-top" src="./access11.jpg"  style="height: 227px;
                    width: 289px;
                "alt="Card image cap">
                    <div class="card-body">
                      <h5 class="card-title">
                        Jumbo Disc Brake for Royal Enfield</h5>
                        <span style="font-weight: 900;"> Price:Rs. 6500</span>
                      <p class="card-text">
                       </p>
                        <a  class="cardbtn" data-toggle="modal" data-target="#myModal">Buy Now</a>
                    </div>
                  </div>  
            </div>
            <div class ="col-lg-3 col-md-3">
                <div class="card" style="width: 18rem;width: 18rem;
                top: 19px;
                left: 33px;">
                    <img class="card-img-top" src="./access12.png"  style= "height: 260px;
                    width: 287px;"alt="Card image cap">
                    <div class="card-body">
                      <h5 class="card-title">
                        Yamaha MT15 Tail Tidy kit</h5>
                        <span style="font-weight: 900;"> Price:Rs. 1495</span>
                      <p class="card-text">
                        </p>
                        <a  class="cardbtn" data-toggle="modal" data-target="#myModal">Buy Now</a>
                    </div>
                  </div>  
            </div>
            <div class ="col-lg-3 col-md-3">
                <div class="card" style="width: 18rem;width: 18rem;
                top: 19px;
                left: 33px;">
                    <img class="card-img-top" src="./access14.webp"  style= "height: 227px;
                    width: 287px;"alt="Card image cap">
                    <div class="card-body">
                      <h5 class="card-title">
                        Fego Float - Air Suspension seat</h5>
                        <span style="font-weight: 900;"> Price:Rs. 1999</span>
                      <p class="card-text">
              </p>
              <a  class="cardbtn" data-toggle="modal" data-target="#myModal">Buy Now</a>
                    </div>
                  </div>  
            </div>
           </div>
        </div>
           
    
    
        </section>
    </div>
  
    <div class="fixed-footer">
        <div class="container">Copyright &copy; 2022 RONALDO BIKE ACCESSORIES</div>     
    </div>
</body>
</html>

<!-- Modal -->
<div id="myModal" class="modal fade" role="dialog">
    <div class="modal-dialog">
  
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          
          <h4 class="modal-title">BUY ACCESSORIES </h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        <div class="modal-body">

          <form action="connect.php" method="post">
            Accessories name: <input type="text" class="form-control" name="name"><br>
            Address: <input type="text" class="form-control" name="address"><br>
            Mobile Number: <input type="number"  class="form-control" name="mobilenumber"><br>
            <input type="submit" name="submit">
            </form>
        <div class="modal-footer">
        </div>
      </div>
  
    </div>
  
  </div>

<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">LOG OFF</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
         Are you sure you want to logout?
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <button type="button" class="btn btn-primary" id="logout1">Log Out</button>
        </div>
      </div>
    </div>
  </div>
<script>
$(document).ready(function() {
    $("#motor").click(function(){
      location.href = 'connect.php';
    }); 
    $("#home").click(function(){
      location.href = 'index.php';
    }); 
    $("#services").click(function(){
      location.href = 'services.html';
    });
    $("#logout1").click(function(){
      location.href = 'login1.php';
    });
    $("#contact").click(function(){
      location.href = 'test.php';
    });
    $("#bookeditem").click(function(){
      location.href = 'Accessories.php';
    });
    
});
  </script>

	<center>
		<?php
     function gyalert($msg) {
        echo "<script type='text/javascript'>alert('$msg');</script>";
    }
	
		$conn = mysqli_connect("localhost", "root", "", "base");
		if($conn === false){
			die("ERROR: Could not connect. "
				. mysqli_connect_error());
		}
		
		$name = $_REQUEST['name'];
		$address = $_REQUEST['address'];
		$mobilenumber = $_REQUEST['mobilenumber'];
	
        if(isset($_POST['submit'])){
		$sql = "INSERT INTO data VALUES ('$name',
			'$address','$mobilenumber')";
		
		if(mysqli_query($conn, $sql)){
            alert("Your item has been booked");

		} else{
			echo "ERROR: Hush! Sorry $sql. "
				. mysqli_error($conn);
		}
		mysqli_close($conn);
    }
		?>
	</center>


</body>

</html>




















