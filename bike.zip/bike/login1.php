<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="./bootstrap.css">
<style>
body, html {
  font-family:Times New Roman, Times New Roman, sans-serif;
  overflow:hidden;
}

* {
  box-sizing: border-box;
}

.bg-img {
  /* The image used */
  /* background-image: url("img.jpg"); */
  background: linear-gradient(to right, #354e3d, #009688);
  min-height: 709px;

  /* Center and scale the image nicely */
  /* background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
  position: relative; */
}

/* Add styles to the form container */
.container {
  position: absolute;
  right: 0;
  margin: 20px;
  max-width: 300px;
  padding: 20px;
  background-color: sandle;
}

/* Full-width input fields */
input[type=text], input[type=password] {
  width: 100%;
  padding: 15px;
  margin: 5px 0 22px 0;
  border: none;
  background:#f1f1f1;
}

input[type=text]:focus, input[type=password]:focus {
  background-color: #ddd;
  outline: none;
}

/* Set a style for the submit button */
.btn {
  background-color: #4CAF50;
  color: white;
  padding: 16px 20px;
  border: none;
  cursor: pointer;
  width: 100%;
  opacity: 0.9;
}

.btn:hover {
  opacity: 1;
  color:white;
}
</style>
</head>
<body>
<div class="row" >
  <div class="col-lg-6 col-md-6">
    <img src="./bike56.jpg" style="width:790px;height:709px">
</div>
<div class="col-lg-6 col-md-6">
<div class="bg-img">
  <div class="row">
    <div class="col-lg-3 col-md-3">
</div>
<div class="col-lg-6 col-md-6">
<form action='db.php'method='POST'class="container">
    <h1 style="color:white">Login</h1>

    <label for="username" style="color:white"><b>Email</b></label>
    <input type="text" placeholder="Enter Username" name="username" required>

    <label for="password" style="color:white"><b>Password</b></label>
    <input type="password" placeholder="Enter Password" name="password" required>

    <button type="submit" name="submit"class="btn">Login</button>
  </form>
</div>
<div class="col-lg-3 col-md-3">
</div>
</div>

</div>

</div>
</div>



</body>
</html>